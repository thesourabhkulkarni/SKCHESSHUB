/* =========================================================
   SKCHESSHUB – UI behaviour & effects
   ========================================================= */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- toast ---------- */
  function toast(msg, ms = 2800) {
    const t = document.createElement('div');
    t.className = 'toast'; t.textContent = msg;
    $('#toasts').appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, ms);
  }

  /* ---------- modals ---------- */
  function openModal(id) { const m = $('#' + id); if (!m) return; m.hidden = false; document.body.classList.add('lock'); const f = $('input,select,button:not(.modal-x)', m); f && setTimeout(() => f.focus({ preventScroll: true }), 50); }
  function closeModal(id) { const m = typeof id === 'string' ? $('#' + id) : id; if (!m) return; m.hidden = true; if (!$$('.modal').some(x => !x.hidden)) document.body.classList.remove('lock'); }
  document.addEventListener('click', e => {
    const o = e.target.closest('[data-open]'); if (o) { closeNav(); openModal(o.dataset.open); }
    if (e.target.closest('[data-close]')) closeModal(e.target.closest('.modal'));
    else if (e.target.classList && e.target.classList.contains('modal')) closeModal(e.target);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { $$('.modal').forEach(closeModal); closeNav(); const p = $('#settingsPop'); p && (p.hidden = true); } });

  /* ---------- sticky header ---------- */
  const header = $('.site-header');
  const onScroll = () => header.classList.toggle('scrolled', scrollY > 10);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---------- mobile drawer + dropdowns ---------- */
  const nav = $('#nav'), burger = $('#burger'), scrim = $('#scrim');
  function openNav() { nav.classList.add('open'); scrim.classList.add('on'); burger.setAttribute('aria-expanded', 'true'); document.body.classList.add('lock'); }
  function closeNav() { nav.classList.remove('open'); scrim.classList.remove('on'); burger.setAttribute('aria-expanded', 'false'); if (!$$('.modal').some(x => !x.hidden)) document.body.classList.remove('lock'); }
  burger.addEventListener('click', () => nav.classList.contains('open') ? closeNav() : openNav());
  scrim.addEventListener('click', closeNav);
  $$('.dd-btn').forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    const dd = b.parentElement, was = dd.classList.contains('open');
    $$('.dd.open').forEach(d => d.classList.remove('open'));
    if (!was) dd.classList.add('open');
    b.setAttribute('aria-expanded', String(!was));
  }));
  document.addEventListener('click', e => { if (!e.target.closest('.dd')) $$('.dd.open').forEach(d => d.classList.remove('open')); });
  $$('.nav a').forEach(a => a.addEventListener('click', () => { closeNav(); $$('.dd.open').forEach(d => d.classList.remove('open')); }));

  /* active nav link on scroll */
  const secs = ['home', 'services', 'about', 'contact'].map(id => document.getElementById(id)).filter(Boolean);
  const home = $('.nav-link.active');
  addEventListener('scroll', () => { if (home) home.classList.toggle('active', scrollY < (secs[1] ? secs[1].offsetTop - 200 : 400)); }, { passive: true });

  /* ---------- reveal on scroll ---------- */
  const rv = $$('.rv');
  rv.forEach((el, i) => el.style.setProperty('--d', (i % 6) * 0.08 + 's'));
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } }), { threshold: .12 });
    rv.forEach(el => io.observe(el));
  } else rv.forEach(el => el.classList.add('in'));

  /* ---------- animated counters ---------- */
  const counters = $$('[data-count]');
  if ('IntersectionObserver' in window) {
    const co = new IntersectionObserver(es => es.forEach(en => {
      if (!en.isIntersecting) return; co.unobserve(en.target);
      const el = en.target, end = +el.dataset.count, dur = reduce ? 1 : 1600, t0 = performance.now();
      (function step(t) { const p = Math.min(1, (t - t0) / dur); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); })(t0);
    }), { threshold: .5 });
    counters.forEach(c => { c.textContent = '0'; co.observe(c); });
  }

  /* ---------- hero parallax (mouse / scroll) ---------- */
  const hero = $('.hero'), king = $('#king');
  if (hero && king && !reduce) {
    hero.addEventListener('pointermove', e => {
      if (e.pointerType === 'touch') return;
      const r = hero.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      king.style.transform = `translate(${x * 18}px,${y * 10}px) rotateY(${x * 8}deg)`;
      $$('.bgp').forEach((p, i) => p.style.translate = `${x * (10 + i * 4)}px ${y * (6 + i * 2)}px`);
    });
    hero.addEventListener('pointerleave', () => { king.style.transform = ''; $$('.bgp').forEach(p => p.style.translate = ''); });
    addEventListener('scroll', () => { if (scrollY < 900) hero.style.setProperty('--sy', scrollY * .08 + 'px'); }, { passive: true });
  }

  /* ---------- 3D tilt on service cards ---------- */
  if (!reduce && matchMedia('(hover:hover)').matches) {
    $$('.svc').forEach(c => {
      c.addEventListener('pointermove', e => {
        const r = c.getBoundingClientRect();
        c.style.setProperty('--ry', ((e.clientX - r.left) / r.width - .5) * 10 + 'deg');
        c.style.setProperty('--rx', (-((e.clientY - r.top) / r.height - .5)) * 10 + 'deg');
      });
      c.addEventListener('pointerleave', () => { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); });
    });
  }

  /* ---------- button ripple ---------- */
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn'); if (!b || reduce) return;
    const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height), sp = document.createElement('span');
    sp.className = 'ripple'; sp.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
    b.appendChild(sp); setTimeout(() => sp.remove(), 650);
  });

  /* ---------- golden dust particles ---------- */
  const cv = $('#dust');
  if (cv && !reduce) {
    const ctx = cv.getContext('2d'); let W, H, ps = [], run = true;
    const size = () => { const r = cv.getBoundingClientRect(); W = cv.width = r.width; H = cv.height = r.height; ps = Array.from({ length: Math.round(Math.min(46, W / 30)) }, mk); };
    const mk = () => ({ x: Math.random() * W, y: Math.random() * H, r: Math.random() * 2 + .6, vy: -(Math.random() * .3 + .08), vx: (Math.random() - .5) * .2, a: Math.random() * .6 + .2, t: Math.random() * 6 });
    size(); addEventListener('resize', size);
    new IntersectionObserver(es => { run = es[0].isIntersecting; if (run) loop(); }).observe(cv);
    function loop() {
      if (!run) return; ctx.clearRect(0, 0, W, H);
      ps.forEach(p => { p.x += p.vx; p.y += p.vy; p.t += .02; if (p.y < -5) { p.y = H + 5; p.x = Math.random() * W; } const a = p.a * (.6 + .4 * Math.sin(p.t)); ctx.beginPath(); ctx.fillStyle = `rgba(232,160,50,${a})`; ctx.shadowColor = 'rgba(255,190,80,.8)'; ctx.shadowBlur = 8; ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill(); });
      requestAnimationFrame(loop);
    }
    loop();
  }

  /* ---------- confetti ---------- */
  function confetti() {
    if (reduce) return;
    const c = $('#confetti'), x = c.getContext('2d'); c.width = innerWidth; c.height = innerHeight;
    const cols = ['#ec3f0f', '#ff9a3c', '#ffd166', '#2f8a3a', '#17171a', '#fff'];
    const ps = Array.from({ length: 140 }, () => ({ x: innerWidth / 2 + (Math.random() - .5) * 200, y: innerHeight * .55, vx: (Math.random() - .5) * 14, vy: -Math.random() * 15 - 4, s: Math.random() * 7 + 4, c: cols[Math.random() * cols.length | 0], r: Math.random() * 6, vr: (Math.random() - .5) * .4 }));
    let n = 0;
    (function f() { x.clearRect(0, 0, c.width, c.height); ps.forEach(p => { p.vy += .35; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 3, p.s, p.s * .6); x.restore(); }); if (++n < 130) requestAnimationFrame(f); else x.clearRect(0, 0, c.width, c.height); })();
  }

  /* ---------- search ---------- */
  const keymap = { coach: '#services', tournament: '#services', ebook: '#services', software: '#services', set: '#services', practice: '#services', puzzle: 'puzzle', ai: 'play-ai', play: 'play-ai', contact: '#contact', about: '#about' };
  $('#searchForm').addEventListener('submit', e => {
    e.preventDefault(); const q = $('#searchInput').value.trim().toLowerCase(); if (!q) return;
    const k = Object.keys(keymap).find(k => q.includes(k));
    if (!k) return toast('No match for “' + q + '”. Try coaching, tournaments, ebooks…');
    const v = keymap[k]; closeNav();
    if (v[0] === '#') { document.querySelector(v).scrollIntoView({ behavior: 'smooth' }); toast('Showing: ' + k); }
    else act(v);
  });

  /* ---------- auth (demo) ---------- */
  $('#authForm').addEventListener('submit', e => {
    e.preventDefault(); const n = $('#aName').value.trim();
    try { localStorage.setItem('skch_user', n); } catch (_) {}
    closeModal('authModal'); toast('Welcome to SKCHESSHUB, ' + n + '! ♟'); e.target.reset();
  });

  /* ---------- actions (data-action) ---------- */
  function act(a) {
    closeNav();
    if (a === 'coaches') return toast('Coaches Portal is coming soon ♟');
    const G = window.SKCH; if (!G) return;
    const card = $('#play'); card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    card.classList.remove('pulse-card'); void card.offsetWidth; card.classList.add('pulse-card');
    if (a === 'play-ai') setTimeout(() => G.openNewGame('ai'), 450);
    if (a === 'play-online') setTimeout(() => G.openNewGame('online'), 450);
    if (a === 'puzzle') setTimeout(() => G.startPuzzle(), 450);
  }
  document.addEventListener('click', e => { const a = e.target.closest('[data-action]'); if (a) { e.preventDefault(); act(a.dataset.action); } });
  $$('a[href="#"]').forEach(a => a.addEventListener('click', e => e.preventDefault()));

  $('#yr').textContent = new Date().getFullYear();
  window.UI = { toast, openModal, closeModal, confetti, act };
})();
