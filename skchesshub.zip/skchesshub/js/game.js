/* =========================================================
   SKCHESSHUB – chess game
   chess.js (rules)  +  Stockfish (AI, Web Worker)  +  PeerJS (multiplayer)
   ========================================================= */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const UI = () => window.UI || { toast() {}, openModal() {}, closeModal() {}, confetti() {} };

  if (typeof Chess === 'undefined') {
    const st = $('#status'); if (st) st.textContent = 'Could not load the chess engine library. Check your connection.';
    return;
  }

  const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const PIECE = (c, t) => `https://cdn.jsdelivr.net/gh/lichess-org/lila@master/public/piece/cburnett/${c}${t.toUpperCase()}.svg`;
  const FILES = 'abcdefgh';
  const other = c => (c === 'w' ? 'b' : 'w');

  /* Stockfish sources (tried in order). Drop a copy at /js/stockfish.js to self-host. */
  const SF_URLS = [
    'https://cdnjs.cloudflare.com/ajax/libs/stockfish.js/10.0.2/stockfish.js',
    'https://cdn.jsdelivr.net/npm/stockfish.js@10.0.2/stockfish.js',
    'js/stockfish.js'
  ];

  const LEVELS = [
    { name: 'Beginner', elo: 800, skill: 0, depth: 1, time: 150, fb: 1 },
    { name: 'Easy', elo: 1200, skill: 5, depth: 3, time: 300, fb: 1 },
    { name: 'Intermediate', elo: 1600, skill: 10, depth: 6, time: 600, fb: 2 },
    { name: 'Advanced', elo: 2000, skill: 15, depth: 10, time: 900, fb: 2 },
    { name: 'Master', elo: 2500, skill: 20, depth: 14, time: 1500, fb: 3 }
  ];

  const PUZZLES = [
    { title: 'Back-rank mate in 1', fen: '6k1/5ppp/8/8/8/8/8/4R1K1 w - - 0 1' },
    { title: "Scholar's mate in 1", fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4' },
    { title: "Fool's mate in 1 (Black to move)", fen: 'rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2' },
    { title: 'Queen & king mate in 1', fen: 'k7/2Q5/1K6/8/8/8/8/8 w - - 0 1' },
    { title: 'Rook finish – mate in 1', fen: '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1' }
  ];

  const settings = Object.assign({ sound: true, legal: true, theme: 'green' }, (() => { try { return JSON.parse(localStorage.getItem('skch_set')) || {}; } catch (_) { return {}; } })());
  const saveSettings = () => { try { localStorage.setItem('skch_set', JSON.stringify(settings)); } catch (_) {} };

  /* ---------- state ---------- */
  const S = {
    game: new Chess(), mode: 'ai', myColor: 'w', flipped: false,
    sel: null, legal: [], fens: [START], viewIdx: null,
    base: 600, inc: 0, clocks: { w: 600, b: 600 }, lastTick: performance.now(),
    over: false, thinking: false, level: 2, opts: null,
    engine: null, enginePromise: null, reqFen: '',
    peer: null, conn: null, isHost: false, puzzleIdx: -1, solved: false
  };

  const boardEl = $('#board');

  /* ---------- sound ---------- */
  let actx;
  function beep(kind) {
    if (!settings.sound) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = 'triangle'; o.frequency.value = kind === 'cap' ? 200 : kind === 'end' ? 392 : 320;
      g.gain.setValueAtTime(.12, actx.currentTime); g.gain.exponentialRampToValueAtTime(.001, actx.currentTime + .13);
      o.connect(g).connect(actx.destination); o.start(); o.stop(actx.currentTime + .14);
    } catch (_) {}
  }

  /* ---------- board build + render ---------- */
  for (let i = 0; i < 64; i++) { const d = document.createElement('div'); d.className = 'sq'; boardEl.appendChild(d); }

  function render() {
    const view = S.viewIdx === null ? S.game : new Chess(S.fens[S.viewIdx]);
    const b = view.board();
    const hist = S.game.history({ verbose: true });
    const at = S.viewIdx === null ? hist.length : S.viewIdx;
    const last = hist[at - 1];
    const inChk = view.in_check(), turn = view.turn();
    const dests = (S.viewIdx === null && settings.legal) ? S.legal : [];
    const cells = boardEl.children;
    for (let i = 0; i < 64; i++) {
      const r = (i / 8) | 0, f = i % 8;
      const rank = S.flipped ? r : 7 - r, file = S.flipped ? 7 - f : f;
      const sq = FILES[file] + (rank + 1), cell = cells[i];
      const p = b[7 - rank][file];
      let cls = 'sq ' + ((rank + file) % 2 === 0 ? 'dark' : 'light');
      if (last && (last.from === sq || last.to === sq)) cls += ' last';
      if (S.sel === sq && S.viewIdx === null) cls += ' sel';
      if (inChk && p && p.type === 'k' && p.color === turn) cls += ' check';
      const d = dests.find(m => m.to === sq);
      if (d) cls += d.captured || d.flags.includes('e') ? ' hintcap' : ' hint';
      cell.className = cls; cell.dataset.sq = sq;
      let html = '';
      if (p) html += `<img class="pc${last && last.to === sq && S.anim ? ' pop' : ''}" draggable="false" src="${PIECE(p.color, p.type)}" alt="${p.color}${p.type}">`;
      if (f === 0) html += `<i class="co r">${rank + 1}</i>`;
      if (r === 7) html += `<i class="co f">${FILES[file]}</i>`;
      cell.innerHTML = html;
    }
    S.anim = false;
    renderMoves(hist, at);
    updateMeta();
    $('#btnFirst').disabled = $('#btnPrev').disabled = at === 0;
    $('#btnNext').disabled = $('#btnLast').disabled = S.viewIdx === null;
  }

  function renderMoves(hist, at) {
    const el = $('#movesList'); let h = '';
    for (let i = 0; i < hist.length; i += 2) {
      const w = hist[i], bl = hist[i + 1];
      h += `<div class="mv-row"><span class="n">${i / 2 + 1}.</span><button data-i="${i + 1}" class="${at === i + 1 ? 'cur' : ''}">${w.san}</button>${bl ? `<button data-i="${i + 2}" class="${at === i + 2 ? 'cur' : ''}">${bl.san}</button>` : '<span></span>'}</div>`;
    }
    el.innerHTML = h || '<div style="padding:10px;font-size:12px;color:#999">No moves yet</div>';
    el.scrollTop = el.scrollHeight;
  }
  $('#movesList').addEventListener('click', e => {
    const b = e.target.closest('button[data-i]'); if (!b) return;
    const i = +b.dataset.i; S.viewIdx = i >= S.fens.length - 1 ? null : i; clearSel(); render();
  });

  /* ---------- player cards / clocks / status ---------- */
  const fmt = s => { if (!S.base) return '--:--'; s = Math.max(0, s); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(Math.floor(s % 60)).padStart(2, '0'); };
  function sideInfo(c) {
    if (S.mode === 'ai') return c === S.myColor ? { n: 'You', e: 'ELO 1200', ai: false } : { n: 'Computer (AI)', e: 'ELO ' + LEVELS[S.level].elo, ai: true };
    if (S.mode === 'online') return c === S.myColor ? { n: 'You', e: 'Online', ai: false } : { n: 'Opponent', e: S.conn ? 'Connected' : 'Waiting…', ai: false };
    if (S.mode === 'puzzle') return c === S.game.turn() && S.puzzleSide === c ? { n: 'You', e: 'Find the mate', ai: false } : { n: 'Puzzle', e: '', ai: false };
    return { n: c === 'w' ? 'White' : 'Black', e: 'Local player', ai: false };
  }
  function updateMeta() {
    const bot = S.flipped ? 'b' : 'w', top = other(bot);
    const a = sideInfo(top), b = sideInfo(bot);
    $('#nameTop').textContent = a.n; $('#eloTop').textContent = a.e;
    $('#nameBot').textContent = b.n; $('#eloBot').textContent = b.e;
    $('#avTop').innerHTML = `<svg class="i"><use href="#${a.ai ? 'i-robot' : 'i-user'}"/></svg>`;
    $('#avBot').innerHTML = `<svg class="i"><use href="#${b.ai ? 'i-robot' : 'i-user'}"/></svg>`;
    $('#avTop').classList.toggle('you', !a.ai && a.n === 'You'); $('#avBot').classList.toggle('you', !b.ai);
    const t = S.game.turn();
    $('#pTop').classList.toggle('active', !S.over && t === top);
    $('#pBot').classList.toggle('active', !S.over && t === bot);
    updateClocks(); setStatus();
    const titles = { ai: 'Play Chess Online', online: 'Multiplayer Game', local: 'Pass & Play', puzzle: 'Solve Positions' };
    $('#gcTitle').textContent = S.mode === 'puzzle' ? PUZZLES[S.puzzleIdx].title : titles[S.mode];
    $('#liveText').textContent = { ai: 'Live', online: S.conn ? 'Online' : 'Waiting', local: 'Local', puzzle: 'Puzzle' }[S.mode];
  }
  function updateClocks() {
    const bot = S.flipped ? 'b' : 'w', top = other(bot);
    const ct = $('#clockTop'), cb = $('#clockBot');
    ct.textContent = fmt(S.clocks[top]); cb.textContent = fmt(S.clocks[bot]);
    ct.classList.toggle('low', !!S.base && S.clocks[top] < 10 && !S.over);
    cb.classList.toggle('low', !!S.base && S.clocks[bot] < 10 && !S.over);
  }
  function setStatus(txt) {
    let s = txt;
    if (!s) {
      const g = S.game, t = g.turn();
      if (S.over) s = S.resultText || 'Game over';
      else if (S.viewIdx !== null) s = 'Reviewing moves – press ⏭ to return';
      else if (S.mode === 'ai') s = S.thinking ? (S.engine || !S.enginePromise ? 'Computer is thinking…' : 'Loading Stockfish…') : t === S.myColor ? 'Your move' : 'Computer to move';
      else if (S.mode === 'online') s = !S.conn ? 'Waiting for opponent…' : t === S.myColor ? 'Your move' : "Opponent's move";
      else if (S.mode === 'puzzle') s = 'Find the checkmate in one move';
      else s = (t === 'w' ? 'White' : 'Black') + ' to move';
      if (!S.over && g.in_check() && S.viewIdx === null) s += ' — Check!';
    }
    $('#status').textContent = s;
  }
  setInterval(() => {
    const now = performance.now(), dt = (now - S.lastTick) / 1000; S.lastTick = now;
    if (S.over || !S.base || S.mode === 'puzzle' || S.game.history().length < 1 || (S.mode === 'online' && !S.conn)) return;
    const t = S.game.turn(); S.clocks[t] -= dt; updateClocks();
    if (S.clocks[t] <= 0) { S.clocks[t] = 0; updateClocks(); endGame(other(t), 'timeout'); }
  }, 100);

  /* ---------- selection / input ---------- */
  function clearSel() { S.sel = null; S.legal = []; }
  function select(sq) { S.sel = sq; S.legal = S.game.moves({ square: sq, verbose: true }); render(); }
  const mayControl = c => S.mode === 'local' || S.mode === 'puzzle' || c === S.myColor;
  const canMove = () => !S.over && S.viewIdx === null && !S.thinking && !S.solved && (S.mode !== 'online' || !!S.conn) && (S.mode !== 'ai' || S.game.turn() === S.myColor);

  let drag = null;
  boardEl.addEventListener('pointerdown', e => {
    const cell = e.target.closest('.sq'); if (!cell || (e.button && e.button > 0) || !canMove()) return;
    const sq = cell.dataset.sq;
    if (S.sel && S.legal.some(m => m.to === sq)) { attempt(S.sel, sq); return; }
    const p = S.game.get(sq);
    if (p && p.color === S.game.turn() && mayControl(p.color)) {
      select(sq);
      drag = { from: sq, x: e.clientX, y: e.clientY, ghost: null, img: boardEl.querySelector(`[data-sq="${sq}"] .pc`) };
    } else { clearSel(); render(); }
  });
  addEventListener('pointermove', e => {
    if (!drag) return;
    if (!drag.ghost) {
      if (Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 6 || !drag.img) return;
      const g = document.createElement('img'); g.className = 'ghost'; g.src = drag.img.src;
      g.style.width = g.style.height = boardEl.clientWidth / 8 * 1.12 + 'px';
      document.body.appendChild(g); drag.ghost = g; drag.img.style.opacity = '.25';
    }
    drag.ghost.style.left = e.clientX + 'px'; drag.ghost.style.top = e.clientY + 'px';
  });
  addEventListener('pointerup', e => {
    if (!drag) return; const d = drag; drag = null;
    if (!d.ghost) return;
    d.ghost.remove();
    const el = document.elementFromPoint(e.clientX, e.clientY), cell = el && el.closest && el.closest('.sq');
    if (cell && cell.dataset.sq !== d.from && S.legal.some(m => m.to === cell.dataset.sq)) attempt(d.from, cell.dataset.sq); else render();
  });
  addEventListener('pointercancel', () => { if (drag && drag.ghost) drag.ghost.remove(); drag = null; render(); });

  function attempt(from, to) {
    const ms = S.legal.filter(m => m.from === from && m.to === to); if (!ms.length) return;
    if (ms[0].flags.includes('p')) showPromo(ms[0].color, p => commit(from, to, p, 'local'));
    else commit(from, to, undefined, 'local');
  }
  function showPromo(color, cb) {
    const el = $('#promo'); el.innerHTML = ['q', 'r', 'b', 'n'].map(t => `<button data-p="${t}" aria-label="${t}"><img src="${PIECE(color, t)}" alt=""></button>`).join(''); el.hidden = false;
    el.onclick = e => { const b = e.target.closest('button'); if (!b) return; el.hidden = true; el.innerHTML = ''; cb(b.dataset.p); };
  }

  /* ---------- committing moves ---------- */
  function commit(from, to, promo, source) {
    const mv = S.game.move({ from, to, promotion: promo || 'q' });
    if (!mv) return false;
    S.fens.push(S.game.fen()); S.lastTick = performance.now();
    if (S.base && S.inc) S.clocks[mv.color] += S.inc;
    clearSel(); S.viewIdx = null; S.anim = true;
    beep(mv.captured ? 'cap' : 'move');
    if (S.mode === 'online' && source === 'local' && S.conn) S.conn.send({ t: 'move', from, to, promotion: promo });

    if (S.mode === 'puzzle') {
      render();
      if (S.game.in_checkmate()) { S.solved = true; beep('end'); UI().confetti(); showResult('Puzzle solved! ♟', 'Great find – that is checkmate.', true); }
      else { UI().toast('Not mate – try again'); boardEl.classList.add('shake'); setTimeout(() => { boardEl.classList.remove('shake'); S.game.undo(); S.fens.pop(); render(); }, 650); }
      return true;
    }
    render();
    if (checkEnd()) return true;
    if (S.mode === 'ai' && S.game.turn() !== S.myColor) engineMove();
    return true;
  }

  function checkEnd() {
    const g = S.game;
    if (g.in_checkmate()) { endGame(other(g.turn()), 'checkmate'); return true; }
    if (g.in_draw() || g.in_stalemate() || g.in_threefold_repetition() || g.insufficient_material()) {
      const why = g.in_stalemate() ? 'Stalemate' : g.in_threefold_repetition() ? 'Threefold repetition' : g.insufficient_material() ? 'Insufficient material' : 'Draw (50-move rule)';
      endGame(null, why); return true;
    }
    return false;
  }
  function endGame(winner, reason) {
    if (S.over) return; S.over = true; S.thinking = false; beep('end');
    let title, sub, win = false;
    const cn = c => (c === 'w' ? 'White' : 'Black');
    if (!winner) { title = 'Draw'; sub = reason; }
    else {
      const verb = { checkmate: 'by checkmate', timeout: 'on time', resign: 'by resignation' }[reason];
      if (S.mode === 'ai' || S.mode === 'online') { win = winner === S.myColor; title = win ? 'You win! 🎉' : 'You lose'; }
      else title = cn(winner) + ' wins!';
      sub = (winner === S.myColor || S.mode === 'local' ? cn(winner) : cn(winner)) + ' wins ' + verb;
    }
    S.resultText = title + ' – ' + sub;
    render(); showResult(title, sub, win);
    if (win) UI().confetti();
  }
  function showResult(title, sub, good) {
    $('#resTitle').textContent = title; $('#resSub').textContent = sub;
    $('#resNew').textContent = S.mode === 'puzzle' ? 'Next Puzzle' : 'New Game';
    $('#result').hidden = false;
  }
  $('#resClose').onclick = () => { $('#result').hidden = true; };
  $('#resNew').onclick = () => { $('#result').hidden = true; if (S.mode === 'puzzle') startPuzzle((S.puzzleIdx + 1) % PUZZLES.length); else newGameClicked(); };

  /* ---------- Stockfish ---------- */
  function makeWorker(url) {
    const code = `importScripts(${JSON.stringify(url)});`;
    return new Worker(URL.createObjectURL(new Blob([code], { type: 'application/javascript' })));
  }
  async function initEngine() {
    for (const u of SF_URLS) {
      try {
        const w = makeWorker(new URL(u, location.href).href);
        const ok = await new Promise(res => {
          const t = setTimeout(() => res(false), 12000);
          w.onmessage = e => { if (String(e.data).includes('uciok')) { clearTimeout(t); res(true); } };
          w.onerror = () => { clearTimeout(t); res(false); };
          w.postMessage('uci');
        });
        if (ok) { S.engine = w; w.onmessage = onEngineMsg; w.postMessage('isready'); return true; }
        w.terminate();
      } catch (_) {}
    }
    UI().toast('Stockfish could not be loaded – using the built-in engine', 4000);
    return false;
  }
  const ensureEngine = () => (S.enginePromise = S.enginePromise || initEngine());

  function onEngineMsg(e) {
    const line = String(e.data);
    if (!line.startsWith('bestmove')) return;
    const mv = line.split(' ')[1];
    if (!S.thinking || S.mode !== 'ai' || S.game.fen() !== S.reqFen || !mv || mv === '(none)') return;
    applyEngine({ from: mv.slice(0, 2), to: mv.slice(2, 4), promotion: mv[4] });
  }
  function applyEngine(m) { S.thinking = false; commit(m.from, m.to, m.promotion, 'engine'); }

  async function engineMove() {
    if (S.over || S.mode !== 'ai') return;
    S.thinking = true; setStatus();
    const fen = S.game.fen(); S.reqFen = fen;
    const ok = await ensureEngine();
    if (S.reqFen !== fen || S.game.fen() !== fen || !S.thinking) return;
    setStatus();
    const L = LEVELS[S.level];
    if (ok && S.engine) {
      S.engine.postMessage('setoption name Skill Level value ' + L.skill);
      S.engine.postMessage('position fen ' + fen);
      S.engine.postMessage(`go depth ${L.depth} movetime ${L.time}`);
    } else {
      setTimeout(() => { if (S.game.fen() !== fen || !S.thinking) return; const m = fallbackMove(fen, L.fb); m && applyEngine(m); }, 350);
    }
  }

  /* fallback minimax engine (used only if Stockfish cannot load) */
  const PV = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 0 };
  function evalPos(g) {
    let s = 0; const b = g.board();
    for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) {
      const p = b[r][f]; if (!p) continue;
      let v = PV[p.type];
      if ('pnb'.includes(p.type)) v += (7 - Math.abs(3.5 - f) - Math.abs(3.5 - r)) * 4;
      s += p.color === 'w' ? v : -v;
    }
    return s;
  }
  function search(g, d, a, b) {
    if (g.in_checkmate()) return g.turn() === 'w' ? -99999 - d : 99999 + d;
    if (d === 0 || g.game_over()) return g.game_over() ? 0 : evalPos(g);
    const ms = g.moves().sort((x, y) => (y.includes('x') ? 1 : 0) - (x.includes('x') ? 1 : 0));
    if (g.turn() === 'w') { let best = -Infinity; for (const m of ms) { g.move(m); best = Math.max(best, search(g, d - 1, a, b)); g.undo(); a = Math.max(a, best); if (a >= b) break; } return best; }
    let best = Infinity; for (const m of ms) { g.move(m); best = Math.min(best, search(g, d - 1, a, b)); g.undo(); b = Math.min(b, best); if (a >= b) break; } return best;
  }
  function fallbackMove(fen, depth) {
    const g = new Chess(fen), ms = g.moves({ verbose: true }); if (!ms.length) return null;
    const white = g.turn() === 'w'; let best = null, bs = white ? -Infinity : Infinity;
    for (const m of ms.sort(() => Math.random() - .5)) {
      g.move({ from: m.from, to: m.to, promotion: m.promotion });
      const sc = search(g, depth - 1, -Infinity, Infinity) + (depth === 1 ? (Math.random() - .5) * 60 : 0);
      g.undo();
      if (white ? sc > bs : sc < bs) { bs = sc; best = m; }
    }
    return best && { from: best.from, to: best.to, promotion: best.promotion };
  }

  /* ---------- game lifecycle ---------- */
  function startGame(o) {
    S.engine && S.engine.postMessage('stop');
    S.opts = o; S.mode = o.mode; S.myColor = o.color || 'w';
    S.game = new Chess(); S.fens = [START]; S.viewIdx = null; clearSel();
    S.over = false; S.thinking = false; S.solved = false; S.resultText = ''; S.reqFen = '';
    S.base = o.base; S.inc = o.inc || 0; S.clocks = { w: S.base, b: S.base }; S.lastTick = performance.now();
    S.flipped = S.mode === 'local' ? false : S.myColor === 'b';
    $('#result').hidden = true; $('#promo').hidden = true;
    S.engine && S.engine.postMessage('ucinewgame');
    render();
    if (S.mode === 'ai') { ensureEngine(); if (S.game.turn() !== S.myColor) engineMove(); }
  }
  function startPuzzle(i) {
    if (S.mode === 'online' && S.conn) { UI().toast('Leave the online game first'); return; }
    S.puzzleIdx = typeof i === 'number' ? i : (S.puzzleIdx + 1) % PUZZLES.length;
    const p = PUZZLES[S.puzzleIdx], g = new Chess(p.fen);
    S.mode = 'puzzle'; S.game = g; S.fens = [p.fen]; S.viewIdx = null; clearSel();
    S.over = false; S.thinking = false; S.solved = false; S.puzzleSide = g.turn(); S.myColor = g.turn();
    S.base = 0; S.clocks = { w: 0, b: 0 }; S.flipped = g.turn() === 'b'; S.opts = { mode: 'puzzle' };
    $('#result').hidden = true; $('#promo').hidden = true; render();
  }
  function resetBoard() {
    if (S.mode === 'online') {
      if (!S.conn) return UI().toast('No opponent connected');
      S.conn.send({ t: 'req', what: 'reset' }); return UI().toast('Reset request sent…');
    }
    if (S.mode === 'puzzle') return startPuzzle(S.puzzleIdx);
    startGame(S.opts || { mode: 'ai', color: 'w', base: 600, inc: 0 });
    UI().toast('Board reset');
  }
  function newGameClicked() {
    if (S.mode === 'online' && S.conn) { S.conn.send({ t: 'req', what: 'rematch' }); return UI().toast('Rematch request sent…'); }
    openNewGame(S.mode === 'puzzle' ? 'ai' : S.mode);
  }
  function resign() {
    if (S.over || S.mode === 'puzzle' || S.game.history().length === 0) return UI().toast('Nothing to resign yet');
    const loser = S.mode === 'local' ? S.game.turn() : S.myColor;
    if (S.mode === 'online' && S.conn) S.conn.send({ t: 'resign' });
    endGame(other(loser), 'resign');
  }

  /* ---------- history buttons ---------- */
  const cur = () => (S.viewIdx === null ? S.fens.length - 1 : S.viewIdx);
  const goto = i => { i = Math.max(0, Math.min(S.fens.length - 1, i)); S.viewIdx = i === S.fens.length - 1 ? null : i; clearSel(); render(); };
  $('#btnFirst').onclick = () => goto(0);
  $('#btnPrev').onclick = () => goto(cur() - 1);
  $('#btnNext').onclick = () => goto(cur() + 1);
  $('#btnLast').onclick = () => goto(S.fens.length - 1);
  addEventListener('keydown', e => {
    if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
    if (e.key === 'ArrowLeft') goto(cur() - 1); else if (e.key === 'ArrowRight') goto(cur() + 1);
  });
  $('#btnNew').onclick = newGameClicked;
  $('#btnReset').onclick = resetBoard;

  /* ---------- settings popover ---------- */
  const pop = $('#settingsPop');
  $('#btnSettings').onclick = e => { e.stopPropagation(); pop.hidden = !pop.hidden; };
  document.addEventListener('click', e => { if (!e.target.closest('.gear-wrap')) pop.hidden = true; });
  pop.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.set === 'flip') { S.flipped = !S.flipped; render(); }
    if (b.dataset.set === 'reset') { pop.hidden = true; resetBoard(); }
    if (b.dataset.set === 'resign') { pop.hidden = true; resign(); }
    if (b.dataset.theme) { settings.theme = b.dataset.theme; applyTheme(); saveSettings(); }
  });
  $('#optSound').onchange = e => { settings.sound = e.target.checked; saveSettings(); };
  $('#optLegal').onchange = e => { settings.legal = e.target.checked; saveSettings(); render(); };
  function applyTheme() { boardEl.dataset.theme = settings.theme; $$('.themes button').forEach(b => b.classList.toggle('on', b.dataset.theme === settings.theme)); }
  $('#optSound').checked = settings.sound; $('#optLegal').checked = settings.legal; applyTheme();

  /* ---------- new game modal ---------- */
  const ng = { mode: 'ai', color: 'w' };
  const levelSel = $('#levelSel');
  levelSel.innerHTML = LEVELS.map((l, i) => `<option value="${i}" ${i === S.level ? 'selected' : ''}>${l.name} (ELO ~${l.elo})</option>`).join('');
  function syncModal() {
    $$('#ngTabs button').forEach(b => b.classList.toggle('on', b.dataset.mode === ng.mode));
    $$('.field[data-for]').forEach(f => { const k = f.dataset.for.split(' '); f.hidden = !(k.includes(ng.mode) || (ng.mode === 'local' && k.includes('local-color') && false)); });
    $('#roomPanel').hidden = ng.mode !== 'online';
    $('#startBtn').hidden = ng.mode === 'online';
  }
  $('#ngTabs').onclick = e => { const b = e.target.closest('button'); if (!b) return; ng.mode = b.dataset.mode; syncModal(); };
  $('#colorChips').onclick = e => { const b = e.target.closest('button'); if (!b) return; ng.color = b.dataset.color; $$('#colorChips button').forEach(x => x.classList.toggle('on', x === b)); };
  function openNewGame(mode) { ng.mode = mode || ng.mode; syncModal(); UI().openModal('newGameModal'); }
  const readTime = () => { const [m, i] = $('#timeSel').value.split(',').map(Number); return { base: m * 60, inc: i }; };
  const pickColor = () => (ng.color === 'r' ? (Math.random() < .5 ? 'w' : 'b') : ng.color);
  $('#startBtn').onclick = () => {
    leaveOnline();
    S.level = +levelSel.value; const t = readTime();
    startGame({ mode: ng.mode, color: ng.mode === 'local' ? 'w' : pickColor(), base: t.base, inc: t.inc });
    UI().closeModal('newGameModal');
    UI().toast(ng.mode === 'ai' ? `Game started vs Stockfish (${LEVELS[S.level].name})` : 'Game started – good luck!');
  };

  /* ---------- multiplayer (PeerJS / WebRTC) ---------- */
  const ROOM = 'skchesshub-';
  const genCode = () => Array.from({ length: 5 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.random() * 32 | 0]).join('');
  function leaveOnline() { try { S.conn && S.conn.close(); S.peer && S.peer.destroy(); } catch (_) {} S.conn = null; S.peer = null; }
  const msg = t => ($('#roomMsg').textContent = t);

  function createRoom() {
    if (typeof Peer === 'undefined') return msg('Multiplayer library failed to load. Check your connection.');
    leaveOnline(); S.isHost = true;
    const code = genCode(); msg('Creating room…');
    const peer = S.peer = new Peer(ROOM + code);
    peer.on('open', () => { $('#roomCode').textContent = code; $('#roomCodeBox').hidden = false; msg('Waiting for your friend to join…'); });
    peer.on('connection', c => { if (S.conn) { c.close(); return; } wire(c); });
    peer.on('error', err => { if (err.type === 'unavailable-id') createRoom(); else msg('Connection error: ' + err.type); });
    ngHost = { color: pickColor(), time: readTime() };
  }
  let ngHost = null;
  function joinRoom(code) {
    if (typeof Peer === 'undefined') return msg('Multiplayer library failed to load.');
    code = (code || '').trim().toUpperCase(); if (code.length !== 5) return msg('Enter the 5-character room code.');
    leaveOnline(); S.isHost = false; msg('Connecting…');
    const peer = S.peer = new Peer();
    peer.on('open', () => wire(peer.connect(ROOM + code, { reliable: true })));
    peer.on('error', err => msg(err.type === 'peer-unavailable' ? 'Room not found. Check the code.' : 'Connection error: ' + err.type));
    setTimeout(() => { if (!S.conn) msg('Still connecting… make sure the host created the room.'); }, 9000);
  }
  function wire(c) {
    c.on('open', () => {
      S.conn = c;
      if (S.isHost) {
        const hc = ngHost.color, t = ngHost.time;
        startGame({ mode: 'online', color: hc, base: t.base, inc: t.inc });
        c.send({ t: 'start', color: other(hc), base: t.base, inc: t.inc });
        UI().closeModal('newGameModal'); UI().toast('Opponent joined – you play ' + (hc === 'w' ? 'White' : 'Black'));
      }
    });
    c.on('data', onData);
    c.on('close', () => { if (S.conn === c) { S.conn = null; UI().toast('Opponent disconnected'); if (S.mode === 'online') render(); } });
    c.on('error', () => UI().toast('Connection problem'));
  }
  function onData(d) {
    if (!d || !d.t) return;
    if (d.t === 'start') { startGame({ mode: 'online', color: d.color, base: d.base, inc: d.inc }); UI().closeModal('newGameModal'); UI().toast('Connected! You play ' + (d.color === 'w' ? 'White' : 'Black')); }
    else if (d.t === 'move') { if (S.mode === 'online' && !S.over) { S.viewIdx = null; commit(d.from, d.to, d.promotion, 'remote'); } }
    else if (d.t === 'resign') endGame(S.myColor, 'resign');
    else if (d.t === 'req') {
      const txt = d.what === 'reset' ? 'reset the board' : 'start a new game (colours swap)';
      if (confirm('Your opponent wants to ' + txt + '. Accept?')) { S.conn.send({ t: 'ack', what: d.what }); applyReq(d.what); }
      else S.conn.send({ t: 'deny', what: d.what });
    }
    else if (d.t === 'ack') applyReq(d.what);
    else if (d.t === 'deny') UI().toast('Opponent declined');
  }
  function applyReq(what) {
    startGame({ mode: 'online', color: what === 'rematch' ? other(S.myColor) : S.myColor, base: S.base, inc: S.inc });
    UI().toast(what === 'reset' ? 'Board reset' : 'New game – colours swapped');
  }
  $('#createRoom').onclick = createRoom;
  $('#joinBtn').onclick = () => joinRoom($('#joinInput').value);
  $('#joinInput').addEventListener('keydown', e => { if (e.key === 'Enter') joinRoom(e.target.value); });
  $('#copyLink').onclick = () => {
    const url = location.origin + location.pathname + '?room=' + $('#roomCode').textContent;
    (navigator.clipboard ? navigator.clipboard.writeText(url) : Promise.reject()).then(() => UI().toast('Invite link copied'), () => UI().toast('Room code: ' + $('#roomCode').textContent));
  };

  /* ---------- boot ---------- */
  S.level = 2;
  startGame({ mode: 'ai', color: 'w', base: 600, inc: 0 });
  window.SKCH = { openNewGame, startPuzzle, startGame };

  const room = new URLSearchParams(location.search).get('room');
  if (room) setTimeout(() => { openNewGame('online'); $('#joinInput').value = room.toUpperCase(); joinRoom(room); }, 600);
})();
